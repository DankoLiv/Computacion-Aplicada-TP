#!/bin/bash

mostrar_help() {
	echo "Uso: $0 [-h] Origen Destino"
	echo 
	echo "realiza un backup completo del directorio Origen hacia uno Destino."
	echo "El nombre del archivo de backup incluirá el nombre del directorio otigen y su fecha de creación."
	echo
	echo "Opciones:"
	echo "-h Muestra esta opción de ayuda y tambien la cierra"
	echo "Ejemplo de uso: "
	echo "Ejemplo: $0 /etc /backup_dir"
}

if [[ "$1" == "-h" ]]; then
	show_help
	exit 0 
elif [[ $# -ne 2 ]]; then
	echo "Error: se requieren dos argumentos para el script: Origen y Destino" 
	show_help 
	exit 1
fi 

origen="$1"
destino="$2"
fecha=$(date +%Y%m%d)
nombre_archivo=$(basename "$origen")_bkp_$fecha.tar.gz

if [[ ! -d "$origen" ]]; then 
	echo "Error: El directorio de origen $origen no existe o no está montado."
	exit 1
fi 
if [[ ! -d "$destino" ]]; then
	echo "Error: El directorio de destino $destino no existe o no está montado."
	exit 1
fi 

echo "Iniciando backup de $origen a $destino/$nombre_archivo" 
tar -czf "$destino/$nombre_archivo" -C "$origen" . 

if [[ $? -eq 0 ]]; then 
	echo "Backup completado exitosamente: $destino/$nombre_archivo"
else
	echo "Error: Fallo al realizar el backup."
	exit 1
fi
